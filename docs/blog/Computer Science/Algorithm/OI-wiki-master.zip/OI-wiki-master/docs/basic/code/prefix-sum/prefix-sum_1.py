from itertools import accumulate

input()
print(*accumulate(map(int, input().split())))
